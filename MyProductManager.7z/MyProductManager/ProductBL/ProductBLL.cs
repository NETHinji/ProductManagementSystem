﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ProductDAL;
using ProductEntities;
using ProductExceptions;

namespace ProductBL
{
    public class ProductBLL
    {
        public DataTable SearchByCategoryBLL(int categoryId)
        {
            DataTable dt = null;
            try
            {
                ProductDL productDL = new ProductDL();
                dt=productDL.SearchByCategoryDL(categoryId);
            }
            catch(ProductException)
            {
                throw;
            }
            return dt;
        }
        public int AddProduct(Product pobj)
        {
            int productAdded = 0;
            try
            {
                if (ValidateProduct(pobj))
                {
                    ProductDL pDL = new ProductDL();
                    productAdded=pDL.AddProduct(pobj);
                }
            }
            catch (ProductException)
            {
                throw;
            }
            return productAdded;
        }

        private bool ValidateProduct(Product pobj)
        {
            StringBuilder sb = new StringBuilder();
            bool value = true;
            //Regex reg = new Regex();
            char[] productname = pobj.ProductName.ToCharArray();
            if((productname[0]!='C') || (pobj.ProductName.Length<=6))
            {
               
                    value = false;
                    sb.Append(Environment.NewLine + "Invalid product name");
                
            }
            if (pobj.Price<5000)
            {
                value = false;
                sb.Append(Environment.NewLine + "Invalid product price");
            }
            if (value == false)
                throw new ProductException(sb.ToString());
            return value;
        }

        public Product Search(int productId)
        {
            try
            {
                ProductDL pdl = new ProductDL();
                return pdl.Search(productId);
            }
            catch (ProductException)
            {
                throw;
            }
        }

        public DataTable DisplayProductsBLL()
        {
            try
            {
                ProductDL pd = new ProductDL();
                return pd.DisplayProductsDL();
            }
            catch (ProductException)
            {
                throw;
            }
        }
        public DataTable GetCategories()
        {
            try
            {
                ProductDL pDL = new ProductDL();
                return pDL.GetCategories();
            }
            catch (ProductException)
            {
                throw;
            }
        }
    }
}
