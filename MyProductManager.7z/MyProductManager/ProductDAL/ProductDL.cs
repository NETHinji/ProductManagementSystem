﻿using ProductEntities;
using ProductExceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductDAL
{
    public class ProductDL
    {
        string conStr = @"data source=ndamssql\sqlilearn;user id=sqluser;password=sqluser;initial catalog=Training_19Sep18_Pune";
        SqlConnection con;
        SqlCommand com;

        public DataTable SearchByCategoryDL(int categoryId)
        {
            DataTable dt = null;

            try
            {
                con = new SqlConnection(conStr);

                com = new SqlCommand("Sleeper.uspGetProductsByCategory", con);

                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@cId", categoryId);

                con.Open();
                SqlDataReader dr = com.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (ProductException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }

        public DataTable DisplayProductsDL()
        {
            DataTable dt = null;

            try
            {
                con = new SqlConnection(conStr);
                
                com = new SqlCommand("Sleeper.uspGetProducts",con);
                
                com.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = com.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (ProductException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }


        public Product Search(int productId)
        {
            Product p = null;

            try
            {
                con = new SqlConnection(conStr);
                
                com = new SqlCommand("Sleeper.uspSearchProduct",con);
               
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@pId", productId);

                con.Open();
                SqlDataReader dr = com.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    p = new Product
                    {
                        ProductId = int.Parse(dr["ProductId"].ToString()),
                        ProductName = dr["ProductName"].ToString(),
                        
                        Price = decimal.Parse(dr["Price"].ToString()),
                        
                        Category = int.Parse(dr["Category"].ToString())
                    };
                    dr.Close();
                }
            }
            catch (ProductException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return p;
        }


        public int AddProduct(Product productObj)
        {
            int pid = 0;
            try
            {
                con = new SqlConnection(conStr);
                 
                com = new SqlCommand("Sleeper.uspAddProduct", con);
                
                com.CommandType = CommandType.StoredProcedure;

                com.Parameters.Add("@pId", SqlDbType.Int);
                com.Parameters["@pId"].Direction = ParameterDirection.Output;

                com.Parameters.AddWithValue("@pName", productObj.ProductName);
                
                com.Parameters.AddWithValue("@price", productObj.Price);
                
                com.Parameters.AddWithValue("@cat", productObj.Category);

                con.Open();
                
                com.ExecuteNonQuery();
                pid = int.Parse(com.Parameters["@pId"].Value.ToString());
            }
            catch (ProductException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }
        public DataTable GetCategories()
        {
            DataTable dt = null;
            try
            {
                 con = new SqlConnection(conStr);
                
                com = new SqlCommand("Sleeper.uspGetCategories",con);
                
                com.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = com.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (SqlException ex)
            {
                throw new ProductException(ex.Message);
            }
            catch (SystemException ex)
            {
                throw new ProductException(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
    }
}
