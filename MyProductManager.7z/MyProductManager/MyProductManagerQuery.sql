use Training_19Sep18_Pune


create schema Sleeper

create table Sleeper.Category
(
CategoryId int identity(1,1) primary key,
CategoryName varchar(50) not null unique
)

insert into Sleeper.Category 
values ('Watches'),('Laptops'),('Mobiles')

create proc Sleeper.uspGetCategories
as
begin
	select CategoryId,CategoryName 
	from Sleeper.Category
	order by CategoryId
end

create table Sleeper.Product
(
ProductId int identity(1,1) primary key,
ProductName varchar(25) unique not null,

Price money not null,

Category int not null foreign key references Sleeper.Category(CategoryId)
)

create proc Sleeper.uspAddProduct
(
@pName varchar(25),

@price money,

@cat int,
@pId int output
)
as
begin
	insert into Sleeper.Product
	values(@pName,@price,@cat)
	set @pId = Scope_Identity()
end

create proc Sleeper.uspSearchProduct
(
@pId int
)
as
begin
	select * from Sleeper.Product
	where ProductId = @pid
end

create proc Sleeper.uspGetProducts
as
begin
	select * from Sleeper.Product
end

