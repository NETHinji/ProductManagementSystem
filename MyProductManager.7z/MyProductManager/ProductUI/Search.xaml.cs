﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProductBL;
using ProductEntities;
using ProductExceptions;

namespace ProductUI
{
    /// <summary>
    /// Interaction logic for Search.xaml
    /// </summary>
    public partial class Search : Window
    {
        public Search()
        {
            InitializeComponent();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ProductBLL pb = new ProductBLL();
                Product p = pb.Search(int.Parse(txtProductId.Text));
                if (p != null)
                {
                    txtProductName.Text = p.ProductName;
                    
                    txtPrice.Text = p.Price.ToString();
                    
                    txtCategory.Text = p.Category.ToString();
                    gbProductInfo.Visibility = Visibility.Visible;
                }
                else
                {
                    gbProductInfo.Visibility = Visibility.Hidden;
                    MessageBox.Show
                        ("Product with id "+ txtProductId.Text + " does not exists.");
                }
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }
    }
}
