﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProductExceptions;
using ProductBL;
using System.Data;

namespace ProductUI
{
    /// <summary>
    /// Interaction logic for SearchCategory.xaml
    /// </summary>
    public partial class SearchCategory : Window
    {
        public SearchCategory()
        {
            InitializeComponent();
        }

        private void BtnSearchByCategory_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int categoryID = int.Parse(txtCategory.Text);
                ProductBLL pBLL = new ProductBLL();
                DataTable dt=pBLL.SearchByCategoryBLL(categoryID);
                if(dt!=null)
                {
                    dgSearchByCategory.ItemsSource = dt.DefaultView;
                    dgSearchByCategory.Visibility = Visibility.Visible;
                }
                else
                {
                    dgSearchByCategory.Visibility = Visibility.Hidden;
                    MessageBox.Show("Category Id does not exist or there are no products in this category");
                }
            }
            catch(ProductException ex)
            {
                MessageBox.Show(ex.Message, "Attention");
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message, "Warning");
            }
        }
    }
}
